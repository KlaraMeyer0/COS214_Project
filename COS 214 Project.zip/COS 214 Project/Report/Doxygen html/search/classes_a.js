var searchData=
[
  ['pointofcommunication_0',['PointOfCommunication',['../class_point_of_communication.html',1,'']]]
];
