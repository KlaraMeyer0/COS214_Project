var searchData=
[
  ['pointofcommunication_0',['PointOfCommunication',['../class_point_of_communication.html',1,'PointOfCommunication'],['../class_point_of_communication.html#a00601ef2e8554c7aadce6876f499c5bc',1,'PointOfCommunication::PointOfCommunication()']]],
  ['pointofcommunication_2eh_1',['PointOfCommunication.h',['../_point_of_communication_8h.html',1,'']]],
  ['previous_2',['previous',['../class_starlink_satellite.html#a84732d11abfdc95e2be1b4b46a052bcc',1,'StarlinkSatellite']]],
  ['printequipment_3',['printEquipment',['../class_base_station.html#a5809bd18d89e44fb03dde0cadaa13830',1,'BaseStation::printEquipment()'],['../class_space_station.html#a78d0a01fd18ce4e3674854e034749d25',1,'SpaceStation::printEquipment()'],['../class_station.html#ae0b6cfad4266fe82ab1f55fd33219a9d',1,'Station::printEquipment()']]],
  ['printhumans_4',['printHumans',['../class_base_station.html#a496b1d76ebd4f6667414470dbe51a6e5',1,'BaseStation::printHumans()'],['../class_space_station.html#a42c50da999f44a05962a0afaf435c4b8',1,'SpaceStation::printHumans()'],['../class_station.html#ae91f12c502bc57a24f030c5832225bcc',1,'Station::printHumans()']]]
];
