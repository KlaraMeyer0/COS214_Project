<<COS 214 Project>>

How to compile and run the program:
-Compile using the make file that is included:
    make clean
    make
    make run
-We have a main.cpp that you can use for running the code.
-We don't have any data files

For the unit tests:
-Open the terminal in the directory of the folder that contains the respective unit tests.
-Execute the unit tests using the following commands:
    cmake CMakeLists.txt
    make
    ./runTests